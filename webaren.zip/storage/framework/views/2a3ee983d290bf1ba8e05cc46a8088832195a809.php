

<?php $__env->startSection('content'); ?>



<div class="container-fluid" id="dynamicAddRemove">


    <h1 class="mt-4">Dashboard</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Dashboard</li>
    </ol>
    
    <?php if(Session::has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show " role="alert">
        <strong>Berhasil!</strong> 
        <p><?php echo e(Session::get('success')); ?></p>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger alert-dismissible fade show " role="alert">
        <strong>Error!</strong>  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p class="mt-1"><?php echo e($error); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    <div class="card mb-4">


        <div class="card-header">
            <div class="d-flex bd-highlight ">
                <div class="me-auto p-2 bd-highlight">
                    <a href="<?php echo e(route('produksi')); ?>" class="float-right text-white btn btn-primary">

                        Back
                    </a>
                </div>

            </div>
        </div>

        <div class="card-body">
            <form action="<?php echo e(route('inventori.storebs')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row g-3">
                    <div class="col-sm aj[0]">
                        <label for="">Jumlah BS </label>

                        <input class="form-control showthis" name="bs" type="text" placeholder="Jumlah BS" aria-label="State">
                    </div>
                </div>
                <div class="row g-12">
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary btn-block mt-2">Submit</button>
                    </div>
                </div>
            </form>
        </div>


    </div>

    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('scripts'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.1/js/bootstrap.min.js"></script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webaren\resources\views/inventori/bs.blade.php ENDPATH**/ ?>