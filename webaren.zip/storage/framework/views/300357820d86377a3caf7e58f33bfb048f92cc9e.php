

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Dashboard</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Dashboard</li>
    </ol>
    <div class="card mb-4">
        <div class="card-header ">
            <div class="d-flex bd-highlight ">
                <div class="me-auto p-2 bd-highlight"> <i class="fas fa-table me-1"></i>
                    Data Produksi
                </div>
                <div class="p-2 bd-highlight">
                    <a class="btn btn-primary btn-sm float-right" href="<?php echo e(route('produksi.create')); ?>">
                        <span class="fas fa-table me-1"></span>
                        Tambah Data
                    </a>
                </div>
                <div class="p-2 bd-highlight">
                    <a class="btn btn-primary btn-sm" data-bs-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                        Link with href
                    </a>
                </div>
            </div>

        </div>
        <div class="card-body">
            <div class="collapse" id="collapseExample">
                <div class="card card-body mb-3">
                    <form action="<?php echo e(route('keuangan.export.pdf')); ?>" method="GET">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="sort_by" value="id">
                        <div class="row align-items-center justify-content-center">
                            <div class="col-5 my-1">
                                <label for="formGroupExampleInput">Tanggal Mulai</label>

                                <label class="sr-only" for="inlineFormInputName">Name</label>
                                <input type="date" name="from_date" class="form-control" id="inlineFormInputName" placeholder="Jane Doe">
                            </div>
                            <div class="col-5 my-1">
                                <label for="formGroupExampleInput">Tanggal Akhir</label>

                                <label class="sr-only" for="inlineFormInputGroupUsername">Username</label>
                                <div class="input-group">

                                    <input type="date" name="to_date" class="form-control" id="inlineFormInputGroupUsername" placeholder="Username">
                                </div>
                            </div>

                            <div class="col-auto my-1 pt-3 mt-2">

                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <table id="datatablesSimple" class="table" width="100%">
                <thead>
                    <tr class="table bg-dark text-white">
                        <th scope="col">Urutan Masak</th>
                        <th scope="col">Kode</th>
                        <th scope="col">Jumlah Uang Masuk <small>(Rp)</small></th>
                        <th scope="col">Jumlah Uang Keluar <small>(Rp)</small></th>
                        <th scope="col">Saldo</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                    function rupiah($angka){
	
                        $hasil_rupiah = "Rp " . number_format($angka,2,',','.');
                        return $hasil_rupiah;
                     
                    }
                    ?>
                    <?php $__currentLoopData = $a; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td> <?php if($row->kode == 1): ?>
                            <h4><span class="badge bg-warning">DW</span></h4>
                        <?php elseif($row->kode==2): ?>
                            <h4><span class="badge bg-primary">AM</span></h4>
                        <?php else: ?>
                            <h4><span class="badge bg-danger">FD</span></h4>
                        <?php endif; ?></td>
                        <td><?php echo e(rupiah($row->total_bahan)); ?></td>
                        <td><?php echo e(rupiah($row->total_kel)); ?></td>
                        <td><?php echo e(rupiah($row->total_bahan - $row->total_kel )); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webaren\resources\views/keuangan/rekap.blade.php ENDPATH**/ ?>