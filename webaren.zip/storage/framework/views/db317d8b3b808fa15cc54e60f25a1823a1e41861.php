

<?php $__env->startSection('content'); ?>


<div class="container-fluid px-4 mb-3">
    <h1 class="mt-4">Dashboard</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Dashboard</li>
    </ol>
    <div class="row">
        <div class="col-sm-6 col-md-5 offset-md-2 col-lg-6 offset-lg-0">
            <div class="card">
                <div class="card-header">
                    <?php if(session('status')): ?>
                    <?php echo e(session('status')); ?>

                    <?php endif; ?>
                    <?php if(Session::has('success')): ?>
                    <div class="alert alert-success text-center">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <p><?php echo e(Session::get('success')); ?></p>
                    </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger text-center">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($error); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>
                    <h3 class="card-title">POS</h3>
                    <?php if($produksi_detail->count() > 0): ?>
                    <small>Total Data : <?php echo e($keranjang->total()); ?></small>
                    <?php else: ?>
                    <small>Total Data : 0</small>
                    <?php endif; ?>
                </div>
                <?php if($produksi_detail->count() > 0): ?>

                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <?php $__currentLoopData = $keranjang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div id="Mylist" class="list-group  pb-3">
                                <a href="#" class="list-group-item list-group-item-action flex-column align-items-start ">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h5 class="mb-1">NWO</h5>
                                        <small><?php echo e($row->created_at->diffForHumans()); ?></small>
                                    </div>
                                    <div class="d-flex w-100  justify-content-between">
                                        <p class="mb-1"><?php echo e($row->nwo); ?></p>

                                    </div>
                                    <button data-id="<?php echo e($row->id); ?>" data-ar="<?php echo e($row->ar); ?>" data-nwo="<?php echo e($row->nwo); ?>" data-aj="<?php echo e($row->aj); ?>" data-toi="<?php echo e($row->toi); ?>" data-gt="<?php echo e($row->gt); ?>" data-gp="<?php echo e($row->gp); ?>" data-k="<?php echo e($row->k); ?>" data-tjawa="<?php echo e($row->tjawa); ?>" data-rbs="<?php echo e($row->rbs); ?>" class="btn btn-warning" id="submit<?php echo e($row->id); ?>" type="button" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-edit"></i></button>
                                </a>
                                <a href="#" class="list-group-item list-group-item-action flex-column align-items-start">
                                    <ul class="list-group">
                                        <li class="list-group-item d-flex justify-content-between  align-items-center">
                                            <div class="d-inline p-2 text-light bg-dark rounded ">AJ<span class="ml-2 badge badge-light"><?php echo e($row->aj); ?> kg</span></div>
                                            <div class="d-inline p-2 bg-dark text-white rounded justify-content-between">AR<span class="ml-2 badge badge-light"><?php echo e($row->ar); ?> kg</span></div>
                                            <div class="d-inline p-2 bg-dark text-white rounded justify-content-between">GP<span class="ml-2 badge badge-light"><?php echo e($row->gp); ?> kg</span></div>
                                            <div class="d-inline p-2 bg-dark text-white rounded">GT<span class="ml-2 badge badge-light"><?php echo e($row->gt); ?> kg</span></div>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <div class="d-inline p-2 text-light bg-dark rounded text-white">TOI<span class="ml-2 badge badge-light"><?php echo e($row->toi); ?> kg</span></div>
                                            <div class="d-inline p-2 bg-dark text-white rounded justify-content-between">K<span class="ml-2 badge badge-light"><?php echo e($row->k); ?> kg</span></div>
                                            <div class="d-inline p-2 bg-dark text-white rounded justify-content-between">T-J<span class="ml-2 badge badge-light"><?php echo e($row->tjawa); ?> kg</span></div>
                                            <div class="d-inline p-2 bg-dark text-white rounded">R-BS<span class="ml-2 badge badge-light"><?php echo e($row->rbs); ?> kg</span></div>
                                        </li>
                                    </ul>
                                </a>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>

                    </div>
                </div>
                <div class="card-footer">
                    <div class="row">

                        <?php echo e($keranjang->links()); ?>


                    </div>
                </div>
                <?php else: ?>
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div id="Mylist" class="list-group  pb-3">
                                <a href="#" class="list-group-item list-group-item-action flex-column align-items-start ">
                                    <div class="d-flex w-100 justify-content-between">
                                        Kosong
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card card-default">
                <div class="card-header">
                    <form action="<?php echo e(route('produksi.create.cek.update')); ?>" method="post">
                        <?php echo csrf_field(); ?>

                        <h3 class="card-title">
                            Customer
                            <span>
                                <?php if($total_k > 0 && $total_gt > 0 && $total_aj > 0 && $total_ar > 0 && $total_tjawa > 0 && $total_gp > 0 && $total_toi > 0 && $total_gt > 0): ?>
                                <button type="submit" class="btn btn-sm btn-info float-md-right ml-3">Selesai</button>

                                <?php else: ?>
                                <button type="submit" class="btn btn-sm btn-danger float-md-right ml-3" disabled="disabled" alt="error">Selesai</button>

                                <?php endif; ?>
                            </span>
                        </h3>
                        <input type="hidden" name="aj" value="<?php echo e($total_aj); ?>">
                    </form>

                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <?php if($produksi_detail->count() > 0): ?>
                    <ul class="list-group ">
                        <!-- <li class="alert list-group-item bg-danger ">
                                    <ul class="list-group text-white  ">
                                        <li class="list-group-item bg-danger justify-content-between align-items-center">
                                            Quisque hendrerit orci
                                            <span class="badge badge-primary badge-pill float-right">14</span>
                                        </li>
                                        <li class="list-group-item bg-danger justify-content-between align-items-center">
                                            Quisque hendrerit orci
                                            <span class="badge badge-primary badge-pill float-right">14</span>
                                        </li>
                                      
                                    </ul>
                                </li> -->
                        <li class=" list-group-item text-dark d-flex justify-content-between align-items-center">
                            AJ<span class="badge <?php echo e(($total_aj < 0) ? 'bg-secondary' : 'bg-success'); ?> "><?php echo e($total_aj); ?></span>
                        </li>
                        <li class=" list-group-item text-dark d-flex justify-content-between align-items-center">
                            AR
                            <span class="badge  <?php echo e(($total_ar < 0) ? 'bg-danger' : 'bg-success'); ?>"><?php echo e($total_ar); ?></span>
                        </li>
                        <li class=" list-group-item text-dark d-flex justify-content-between align-items-center">
                            GP
                            <span class="badge <?php echo e(($total_gp < 0) ? 'bg-danger' : 'bg-success'); ?>"><?php echo e($total_gp); ?></span>
                        </li>
                        <li class=" list-group-item text-dark d-flex justify-content-between align-items-center">
                            GT
                            <span class="badge <?php echo e(($total_gt < 0) ? 'bg-danger' : 'bg-success'); ?>"><?php echo e($total_gt); ?></span>
                        </li>
                        <li class=" list-group-item text-dark d-flex justify-content-between align-items-center">
                            TOI
                            <span class="badge <?php echo e(($total_toi < 0) ? 'bg-danger' : 'bg-success'); ?>"><?php echo e($total_toi); ?></span>
                        </li>
                        <li class=" list-group-item text-dark d-flex justify-content-between align-items-center">
                            K
                            <span class="badge <?php echo e(($total_k < 0) ? 'bg-danger' : 'bg-success'); ?>"><?php echo e($total_k); ?></span>
                        </li>
                        <li class=" list-group-item text-dark d-flex justify-content-between align-items-center">
                            T-JAWA
                            <span class="badge <?php echo e(($total_tjawa < 0) ? 'bg-danger' : 'bg-success'); ?>"><?php echo e($total_k); ?></span>
                        </li>
                        <li class=" list-group-item text-dark d-flex justify-content-between align-items-center">
                            R-BS
                            <span class="badge <?php echo e(($total_rbs < 0) ? 'bg-danger' : 'bg-success'); ?>"><?php echo e($total_rbs); ?></span>
                        </li>
                    </ul>
                    <?php else: ?>
                    <ul class="list-group ">
                        <!-- <li class="alert list-group-item bg-danger ">
                                    <ul class="list-group text-white  ">
                                        <li class="list-group-item bg-danger justify-content-between align-items-center">
                                            Quisque hendrerit orci
                                            <span class="badge badge-primary badge-pill float-right">14</span>
                                        </li>
                                        <li class="list-group-item bg-danger justify-content-between align-items-center">
                                            Quisque hendrerit orci
                                            <span class="badge badge-primary badge-pill float-right">14</span>
                                        </li>
                                      
                                    </ul>
                                </li> -->
                        <li class=" list-group-item text-dark d-flex justify-content-between align-items-center">
                            Kosong
                        </li>
                    </ul>
                    <?php endif; ?>

                </div>
                <!-- /.card-body -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.1/js/bootstrap.min.js"></script>
<script type="text/javascript">

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webaren\resources\views/produksi/cek.blade.php ENDPATH**/ ?>