<?php

return [
    'flush' => false,
    'pdfLibrary' => 'dompdf' // snappy, dompdf
];
